//сворачивающееся меню
$('.shapka .navbar-toggle').click(function(){
	$('.shapka .navbar-nav').toggleClass('displayBlock');
	$('.shapka').toggleClass('shapkaHeight2');
});
$('.navbar-toggleFix').click(function(){
	$('.navFix').toggleClass('displayBlock');
	$('.shapkaFix').toggleClass('shapkaHeight2Fix');
});

$('.navFix li a').click( function(){
	$('.navFix').removeClass('displayBlock');
	$('.shapkaFix').removeClass('shapkaHeight2Fix');
});
$('.nav li a').click(function(){
	$('.shapka .navbar-nav').removeClass('displayBlock');
	$('.shapka').removeClass('shapkaHeight2');
});

//активация карты (для гугл карты)
$(document).ready(function(){
	$('.overlay').click(function() {
		$(this).remove();
	});
});

//фиксированное меню
$(window).scroll(function(){
	if(document.documentElement.clientWidth > 767) {
		if($(this).scrollTop() >= 100) {
			$('.shapkaFix').addClass('dispBlock');
		}
		else{
			$('.shapkaFix').removeClass('dispBlock');
		};
	}
	else {
		var asz = $('.navbar-nav').css('display');
		if(asz == 'none'){
			if($(this).scrollTop() >= 200) {
				$('.shapkaFix').addClass('dispBlock');
			}
			else{
				$('.shapkaFix').removeClass('dispBlock');
			}
		}
		else{
			if($(this).scrollTop() >= 500) {
				$('.shapkaFix').addClass('dispBlock');
			}
			else{
				$('.shapkaFix').removeClass('dispBlock');
			}
		};
	};
});

//заказ звонка (главная модалка)
	$('.vizovGlMod').click( function(){
		$('.ebmn').fadeIn(400,
		 	function(){
				$('.oknoZakZv_modVspliv')
					.css('display', 'block')
					.animate({opacity: 1, top: '50%'}, 200);
		});
	});
  $('.ebmn').click( function(){
		$('.oknoZakZv_modVspliv')
			.animate({opacity: 0, top: '45%'}, 200,
				function(){
					$(this).css('display', 'none');
					$('.ebmn').fadeOut(600);
				}
			);
	});

	//заказ звонка (остались вопросы)
		$('.zadVoprosi, .vizovOstVopr').click( function(){
			$('.ebmn').fadeIn(400,
			 	function(){
					$('.oknoZakZv_modOstVoprosi')
						.css('display', 'block')
						.animate({opacity: 1, top: '50%'}, 200);
			});
		});
	  $('.ebmn').click( function(){
			$('.oknoZakZv_modOstVoprosi')
				.animate({opacity: 0, top: '45%'}, 200,
					function(){
						$(this).css('display', 'none');
						$('.ebmn').fadeOut(600);
					}
				);
		});

		//заказ звонка (получить помощь)
			$('.forknopkiPom').click( function(){
				$('.ebmn').fadeIn(400,
				 	function(){
						$('.oknoZakZv_modPolPom')
							.css('display', 'block')
							.animate({opacity: 1, top: '50%'}, 200);
				});
			});
		  $('.ebmn').click( function(){
				$('.oknoZakZv_modPolPom')
					.animate({opacity: 0, top: '45%'}, 200,
						function(){
							$(this).css('display', 'none');
							$('.ebmn').fadeOut(600);
						}
					);
			});

			//заказ звонка (записаться)
				$('.zapisatcjAbsol').click( function(){
					$('.ebmn').fadeIn(400,
						function(){
							$('.oknoZakZv_modZapisatsj')
								.css('display', 'block')
								.animate({opacity: 1, top: '50%'}, 200);
					});
				});
				$('.ebmn').click( function(){
					$('.oknoZakZv_modZapisatsj')
						.animate({opacity: 0, top: '45%'}, 200,
							function(){
								$(this).css('display', 'none');
								$('.ebmn').fadeOut(600);
							}
						);
				});


				//заказ звонка (телефон)
					$('.telFix').click( function(){
						$('.ebmnTel').fadeIn(400,
							function(){
								$('.oknoZakZv_modOstVoprosiTel')
									.css('display', 'block')
									.animate({opacity: 1, top: '50%'}, 200);
						});
					});
					$('.ebmnTel').click( function(){
						$('.oknoZakZv_modOstVoprosiTel')
							.animate({opacity: 0, top: '45%'}, 200,
								function(){
									$(this).css('display', 'none');
									$('.ebmnTel').fadeOut(600);
								}
							);
					});

		//проверка полей для яблока
	//	$("form").submit(function(e) {
  //  var ref = $(this).find("[required]");
  //  $(ref).each(function(){
  //      if ( $(this).val() == '' )
  //      {
  //          alert("Заполните поля");
  //          $(this).focus();
  //          e.preventDefault();
  //          return false;
  //      }
  //  });  return true;
//});


//изображение телефона
$(document).ready(function(){
setTimeout(function() { $('.telFix').animate({opacity: 1}, 2000) }, 60000);
});
