$(".otprMail").submit(function(){ // перехватываем все при событии отправки
			var form = $(this); // запишем форму, чтобы потом не было проблем с this
				var error = false; // предварительно ошибок нет

				if (!error) { // если ошибки нет
						var data = form.serialize(); // подготавливаем данные
						$.ajax({ // инициализируем ajax запрос
							 type: 'POST', // отправляем в POST формате, можно GET
							 url: 'js/mail.php', // путь до обработчика, у нас он лежит в той же папке
							 dataType: 'json', // ответ ждем в json формате
							 data: data, // данные для отправки
							 beforeSend: function(data) { // событие до отправки
										form.find('input[type="submit"]').attr('disabled', 'disabled'); // например, отключим кнопку, чтобы не жали по 100 раз
									},
							 success: function(data){ // событие после удачного обращения к серверу и получения ответа
										if (data['error']) { // если обработчик вернул ошибку
												alert(data['error']); // покажем её текст
										} else { // если все прошло ок
											form.closest('.poiskImg7').find('.img7sekMin').css('display', 'block');
											setTimeout(function() { form.closest('.poiskImg7').find('.img7sekMin').css('display', 'none'); }, 5000);
											form.closest('.poiskImg7').find('.img7sek').css('display', 'block');
											setTimeout(function() { form.closest('.poiskImg7').find('.img7sek').css('display', 'none');
											$('.oknoZakZv_modVspliv, .oknoZakZv_modOstVoprosi, .oknoZakZv_modPolPom, .oknoZakZv_modZapisatsj')
												.animate({opacity: 0, top: '45%'}, 200,
													function(){
														$(this).css('display', 'none');
														$('.ebmn').fadeOut(600);
													}
												); }, 5000);

												//$('.oknoZakZv_modOstVoprosiTel')
												//	.animate({opacity: 0, top: '45%'}, 200,
												//		function(){
												//			$(this).css('display', 'none');
												//			$('.ebmn').fadeOut(600);
												//		}
												//	);

										}
								 },
							 error: function (xhr, ajaxOptions, thrownError) { // в случае неудачного завершения запроса к серверу
										alert(xhr.status); // покажем ответ сервера
										alert(thrownError); // и текст ошибки
								 },
							 complete: function(data) { // событие после любого исхода
										form.find('input[type="submit"]').prop('disabled', false); // в любом случае включим кнопку обратно
								 }

								 });
							$('.for_ZakObrZvTop').val('');/////обнуляем форму


				}
				return false; // вырубаем стандартную отправку формы
				});


				$(".otprMail_zapis").submit(function(){ // перехватываем все при событии отправки
							var form = $(this); // запишем форму, чтобы потом не было проблем с this
								var error = false; // предварительно ошибок нет

								if (!error) { // если ошибки нет
										var data = form.serialize(); // подготавливаем данные
										$.ajax({ // инициализируем ajax запрос
											 type: 'POST', // отправляем в POST формате, можно GET
											 url: 'js/mail_zapis.php', // путь до обработчика, у нас он лежит в той же папке
											 dataType: 'json', // ответ ждем в json формате
											 data: data, // данные для отправки
											 beforeSend: function(data) { // событие до отправки
														form.find('input[type="submit"]').attr('disabled', 'disabled'); // например, отключим кнопку, чтобы не жали по 100 раз
													},
											 success: function(data){ // событие после удачного обращения к серверу и получения ответа
														if (data['error']) { // если обработчик вернул ошибку
																alert(data['error']); // покажем её текст
														} else { // если все прошло ок
															form.closest('.poiskImg7').find('.img7sekMin').css('display', 'block');
															setTimeout(function() { form.closest('.poiskImg7').find('.img7sekMin').css('display', 'none'); }, 5000);
															form.closest('.poiskImg7').find('.img7sek').css('display', 'block');
															setTimeout(function() { form.closest('.poiskImg7').find('.img7sek').css('display', 'none');
															$('.oknoZakZv_modVspliv, .oknoZakZv_modOstVoprosi, .oknoZakZv_modPolPom, .oknoZakZv_modZapisatsj')
																.animate({opacity: 0, top: '45%'}, 200,
																	function(){
																		$(this).css('display', 'none');
																		$('.ebmn').fadeOut(600);
																	}
																); }, 5000);

																$('.oknoZakZv_modOstVoprosiTel')
																	.animate({opacity: 0, top: '45%'}, 200,
																		function(){
																			$(this).css('display', 'none');
																			$('.ebmnTel').fadeOut(600);
																		}
																	);

														}
												 },
											 error: function (xhr, ajaxOptions, thrownError) { // в случае неудачного завершения запроса к серверу
														alert(xhr.status); // покажем ответ сервера
														alert(thrownError); // и текст ошибки
												 },
											 complete: function(data) { // событие после любого исхода
														form.find('input[type="submit"]').prop('disabled', false); // в любом случае включим кнопку обратно
												 }

												 });
											$('.for_ZakObrZvTop').val('');/////обнуляем форму


								}
								return false; // вырубаем стандартную отправку формы
								});
