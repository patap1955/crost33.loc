<?php

$name = htmlentities(strip_tags($_POST['name']));
$phone = htmlentities(strip_tags($_POST['phone']));
$subjectPost = htmlentities(strip_tags($_POST['subject']));

//$to = "vb360677@mail.ru";
$to = 'slobodchikov1985@yandex.ru';
$headers  = "From: От кого письмо <vb360677@mail.ru>\r\n";
$headers .= "Reply-To: reply-vb360677@mail.ru\r\n";
$headers .= "MIME-Version: 5.0\r\n";
$headers .= "Content-Type: text/html;charset=utf-8 \r\n";
$headers .= "Content-Transfer-Encoding: 8bit \r\n";
$subject = $subjectPost;
$message = '';
if ($name !== '') $message .= '<b>Имя заказчика: </b>' . $name . '<br>';
$message .= '<b>Телефон заказчика : </b>' . $phone;

$send = mail ($to, $subject, $message, $headers);
echo json_encode(['success' => 'ok']);
