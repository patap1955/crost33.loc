(function () {
    let formButton = document.querySelectorAll('.form-button')
    formButton.forEach(function (val) {
        val.addEventListener('click', function (e) {
            e.preventDefault()
            const subject = this.dataset.subject
            const formId = this.dataset.alert
            const idModal = this.dataset.modal
            // let data = $('#' + formId).serialize()
            let name = null;
            let phone = document.getElementById(formId + 'Phone').value;
            if (document.getElementById(formId + 'Name')) {
                name = document.getElementById(formId + 'Name').value;
            }

            // Модельное окно с вопросом
            let question = document.getElementById('question')
            const answer = 4
            question.innerText = 'Ответьте на вопрос. Сколько будет два плюс два'
            var modal = document.getElementById("myModal");
            var span = document.getElementsByClassName("close")[0];
            modal.style.display = "block";
            span.onclick = function() {
                modal.style.display = "none";
            }
            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            }
            // Модельное окно с вопросом

            document.getElementById('modal-button').addEventListener('click', function (e) {
                e.preventDefault()
                if (document.getElementById('input-form').value != answer) {
                    document.getElementById('errorAnswer').innerText = 'Ответ на вопрос не верен, попробуйте еще раз!!!'
                } else {
                    $.ajax({
                        type: 'POST',
                        url: 'js/mail.php',
                        dataType: 'json',
                        data: {name, phone, subject},
                        success: function (data) {
                            if (data.success == 'ok') {
                                document.getElementById(formId).reset()
                                document.getElementById('input-form').value = ''
                                modal.style.display = "none";
                                if (document.getElementById(idModal)) {
                                    document.getElementById(idModal).style.display = 'none'
                                    document.querySelector('.ebmn').style.display = 'none'
                                }
                                window.location = "https://vvk37.ru";
                            }
                        }
                    })
                }
            })
        })
    })
})()