-- MySQL dump 10.13  Distrib 5.7.17, for Linux (x86_64)
--
-- Host: localhost    Database: alexmedia_crost
-- ------------------------------------------------------
-- Server version	5.7.21-20-beget-5.7.21-20-1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_download_prices`
--

DROP TABLE IF EXISTS `admin_download_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_download_prices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_download_prices`
--

LOCK TABLES `admin_download_prices` WRITE;
/*!40000 ALTER TABLE `admin_download_prices` DISABLE KEYS */;
INSERT INTO `admin_download_prices` VALUES (1,'sale_asphalt.docx',2,'2022-05-10 10:03:03','2022-10-19 20:18:24'),(2,'lease_technics.xlsx\r\n',4,'2022-05-10 10:03:03','2022-05-10 10:03:03');
/*!40000 ALTER TABLE `admin_download_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_view` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES (1,'Тест','+7 (999) 999 99-99',NULL,NULL,1,'2022-10-28 07:17:45','2022-10-28 07:18:11'),(2,'Тест 2','+7 (999) 999 99-99',NULL,NULL,1,'2022-10-28 07:18:07','2023-01-11 07:13:18'),(3,'Наталия','79990042883',NULL,NULL,1,'2022-12-21 14:01:19','2023-01-11 07:13:24'),(4,'Тест','+7 (999) 999 99-99',NULL,NULL,1,'2022-12-23 05:50:28','2023-01-11 07:13:27'),(5,'Пелагея','79167114430',NULL,NULL,1,'2022-12-25 14:45:26','2023-01-11 07:13:30'),(6,'123','+7 (111) 111 11-11',NULL,NULL,1,'2022-12-30 10:36:29','2023-01-11 07:13:36'),(7,'11111','+7 (122) 222 22-22',NULL,NULL,1,'2022-12-30 10:40:24','2023-01-11 07:13:38'),(8,'тест','+7 (999) 999 99-99',NULL,NULL,1,'2022-12-30 10:41:25','2023-01-11 07:13:40'),(9,'Test','+7 (999) 999 99-99',NULL,NULL,1,'2022-12-30 10:42:36','2023-01-11 07:13:44'),(10,'Ева','79216447801',NULL,NULL,1,'2023-01-08 15:24:14','2023-01-11 07:13:46'),(11,'Тест','+7 (999) 999 99-99',NULL,NULL,1,'2023-01-18 04:20:13','2023-02-10 09:06:36'),(12,'Александра','79161019264',NULL,NULL,1,'2023-01-19 18:43:36','2023-03-28 03:12:08'),(13,'Вика','79895872608',NULL,NULL,1,'2023-01-22 15:53:46','2023-03-28 03:12:05'),(14,'89190207959','+7 (919) 020 79-59',NULL,NULL,1,'2023-01-23 10:30:32','2023-02-10 09:06:52'),(15,'Пелагея','79266798041',NULL,NULL,1,'2023-01-29 16:12:50','2023-03-28 03:11:59'),(16,'Луиза','79268489520',NULL,NULL,1,'2023-02-05 14:53:09','2023-03-28 03:11:55'),(17,'Кира','79363138974',NULL,NULL,1,'2023-02-08 14:53:44','2023-03-28 03:11:53'),(18,'Пелагея','79647808918',NULL,NULL,1,'2023-02-12 15:18:48','2023-03-28 03:11:51'),(19,'Иван','+7 (999) 999 99-99',NULL,NULL,1,'2023-02-15 07:05:20','2023-03-28 03:11:48'),(20,'Надежда','79670300418',NULL,NULL,1,'2023-02-26 15:09:50','2023-03-28 03:11:46'),(21,'Алла','79254616078',NULL,NULL,1,'2023-03-19 15:19:47','2023-03-28 03:11:42'),(22,'Кира','79916820070',NULL,NULL,1,'2023-03-29 16:11:26','2023-03-30 03:55:49'),(23,'александр','+7 (919) 011 44-11',NULL,NULL,1,'2023-04-03 06:18:18','2023-04-03 06:54:06'),(24,'Каролина','79254223728',NULL,NULL,0,'2023-04-26 15:56:41','2023-04-26 15:56:41'),(25,'Злата','79296195193',NULL,NULL,0,'2023-05-02 16:39:48','2023-05-02 16:39:48');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gallaries`
--

DROP TABLE IF EXISTS `gallaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gallaries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_gallary` tinyint(1) NOT NULL DEFAULT '0',
  `status_view` tinyint(1) NOT NULL DEFAULT '1',
  `alt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gallaries`
--

LOCK TABLES `gallaries` WRITE;
/*!40000 ALTER TABLE `gallaries` DISABLE KEYS */;
INSERT INTO `gallaries` VALUES (1,NULL,'uploads/portfolio/1666216825805_photo_2022-09-13_15-08-38.jpg',1,1,NULL,NULL,'2022-10-19 19:00:29','2022-10-19 19:00:34'),(2,NULL,'uploads/portfolio/1666216825821_photo_2022-09-13_15-09-29.jpg',1,1,NULL,NULL,'2022-10-19 19:00:29','2022-10-19 19:00:36'),(3,NULL,'uploads/portfolio/1666216825807_photo_2022-09-13_15-08-42.jpg',1,1,NULL,NULL,'2022-10-19 19:00:29','2022-10-19 19:00:37'),(4,NULL,'uploads/portfolio/1666216825825_photo_2022-09-13_15-12-11.jpg',1,1,NULL,NULL,'2022-10-19 19:00:29','2022-10-19 19:00:39'),(5,NULL,'uploads/portfolio/1666216825808_photo_2022-09-13_15-08-45.jpg',1,1,NULL,NULL,'2022-10-19 19:00:29','2022-10-19 19:00:42'),(6,NULL,'uploads/portfolio/1666216825825_photo_2022-09-13_15-12-15.jpg',1,1,NULL,NULL,'2022-10-19 19:00:29','2022-10-19 19:00:44'),(7,NULL,'uploads/portfolio/1666216825826_photo_2022-09-13_15-12-19.jpg',1,1,NULL,NULL,'2022-10-19 19:00:29','2022-10-19 19:00:46'),(8,NULL,'uploads/portfolio/1666216825828_photo_2022-09-13_15-12-24.jpg',1,1,NULL,NULL,'2022-10-19 19:00:29','2022-10-19 19:00:48'),(9,NULL,'uploads/portfolio/1666216825829_photo_2022-09-13_15-12-28.jpg',1,1,NULL,NULL,'2022-10-19 19:00:29','2022-10-19 19:00:51'),(10,NULL,'uploads/portfolio/1666216825830_photo_2022-09-13_15-15-21.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:00:53'),(11,NULL,'uploads/portfolio/1666216825809_photo_2022-09-13_15-08-49.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:00:55'),(12,NULL,'uploads/portfolio/1666216825810_photo_2022-09-13_15-08-52.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:00:57'),(13,NULL,'uploads/portfolio/1666216825824_photo_2022-09-13_15-12-07.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:01:00'),(14,NULL,'uploads/portfolio/1666216825819_photo_2022-09-13_15-09-19.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:01:03'),(15,NULL,'uploads/portfolio/1666216825820_photo_2022-09-13_15-09-25.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:01:04'),(16,NULL,'uploads/portfolio/1666216825824_photo_2022-09-13_15-12-03.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:01:06'),(17,NULL,'uploads/portfolio/1666216825815_photo_2022-09-13_15-09-04.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:01:09'),(18,NULL,'uploads/portfolio/1666216825817_photo_2022-09-13_15-09-11.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:01:13'),(19,NULL,'uploads/portfolio/1666216825816_photo_2022-09-13_15-09-08.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:01:11'),(20,NULL,'uploads/portfolio/1666216825818_photo_2022-09-13_15-09-15.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:01:15'),(21,NULL,'uploads/portfolio/1666216825822_photo_2022-09-13_15-11-50.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:01:18'),(22,NULL,'uploads/portfolio/1666216825822_photo_2022-09-13_15-11-56.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:01:20'),(23,NULL,'uploads/portfolio/1666216825814_photo_2022-09-13_15-09-01.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:01:22'),(24,NULL,'uploads/portfolio/1666216825823_photo_2022-09-13_15-11-59.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:01:24'),(25,NULL,'uploads/portfolio/1666216825820_photo_2022-09-13_15-09-22.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:01:27'),(26,NULL,'uploads/portfolio/1666216825813_photo_2022-09-13_15-08-56.jpg',1,1,NULL,NULL,'2022-10-19 19:00:30','2022-10-19 19:01:29'),(27,NULL,'uploads/portfolio/1666221577061_photo_2022-09-13_15-07-57.jpg',0,1,NULL,NULL,'2022-10-19 20:19:39','2022-10-19 20:19:39'),(28,NULL,'uploads/portfolio/1666221577063_photo_2022-09-13_15-08-08.jpg',0,1,NULL,NULL,'2022-10-19 20:19:39','2022-10-19 20:19:39'),(29,NULL,'uploads/portfolio/1666221577071_photo_2022-09-13_15-15-59.jpg',0,1,NULL,NULL,'2022-10-19 20:19:39','2022-10-19 20:19:39'),(30,NULL,'uploads/portfolio/1666221577064_photo_2022-09-13_15-08-13.jpg',0,1,NULL,NULL,'2022-10-19 20:19:39','2022-10-19 20:19:39'),(31,NULL,'uploads/portfolio/1666221577069_photo_2022-09-13_15-15-30.jpg',0,1,NULL,NULL,'2022-10-19 20:19:39','2022-10-19 20:19:39'),(32,NULL,'uploads/portfolio/1666221577071_photo_2022-09-13_15-16-03.jpg',0,1,NULL,NULL,'2022-10-19 20:19:39','2022-10-19 20:19:39'),(33,NULL,'uploads/portfolio/1666221577065_photo_2022-09-13_15-08-18.jpg',0,1,NULL,NULL,'2022-10-19 20:19:40','2022-10-19 20:19:40'),(34,NULL,'uploads/portfolio/1666221577066_photo_2022-09-13_15-15-15.jpg',0,1,NULL,NULL,'2022-10-19 20:19:40','2022-10-19 20:19:40'),(35,NULL,'uploads/portfolio/1666221577070_photo_2022-09-13_15-15-45.jpg',0,1,NULL,NULL,'2022-10-19 20:19:40','2022-10-19 20:19:40'),(36,NULL,'uploads/portfolio/1676030939450_photo_2023-01-17_11-28-20.jpg',0,1,NULL,NULL,'2023-02-10 09:09:10','2023-02-10 09:09:10'),(37,NULL,'uploads/portfolio/1676030939447_photo_2023-01-17_11-28-09.jpg',0,1,NULL,NULL,'2023-02-10 09:09:10','2023-02-10 09:09:10'),(38,NULL,'uploads/portfolio/1676030939439_photo_2023-01-17_11-28-02.jpg',0,1,NULL,NULL,'2023-02-10 09:09:10','2023-02-10 09:09:10'),(39,NULL,'uploads/portfolio/1676030939445_photo_2023-01-17_11-28-06.jpg',0,1,NULL,NULL,'2023-02-10 09:09:10','2023-02-10 09:09:10'),(40,NULL,'uploads/portfolio/1676030939449_photo_2023-01-17_11-28-14.jpg',0,1,NULL,NULL,'2023-02-10 09:09:10','2023-02-10 09:09:10'),(41,NULL,'uploads/portfolio/1676031024389_photo_2023-01-17_11-27-29.jpg',0,1,NULL,NULL,'2023-02-10 09:10:32','2023-02-10 09:10:32'),(42,NULL,'uploads/portfolio/1680698378949_WhatsApp Image 2023-04-05 at 14.42.30.jpeg',0,1,NULL,NULL,'2023-04-05 09:39:41','2023-04-05 09:39:41'),(43,NULL,'uploads/portfolio/1680698378950_WhatsApp Image 2023-04-05 at 14.43.48 (1).jpeg',0,1,NULL,NULL,'2023-04-05 09:39:41','2023-04-05 09:39:41'),(44,NULL,'uploads/portfolio/1680698378952_WhatsApp Image 2023-04-05 at 14.43.49.jpeg',0,1,NULL,NULL,'2023-04-05 09:39:41','2023-04-05 09:39:41'),(45,NULL,'uploads/portfolio/1680698378951_WhatsApp Image 2023-04-05 at 14.43.48.jpeg',0,1,NULL,NULL,'2023-04-05 09:39:42','2023-04-05 09:39:42'),(46,NULL,'uploads/portfolio/1680698378952_WhatsApp Image 2023-04-05 at 14.43.49 (2).jpeg',0,1,NULL,NULL,'2023-04-05 09:39:42','2023-04-05 09:39:42'),(47,NULL,'uploads/portfolio/1680698378951_WhatsApp Image 2023-04-05 at 14.43.49 (1).jpeg',0,1,NULL,NULL,'2023-04-05 09:39:42','2023-04-05 09:39:42');
/*!40000 ALTER TABLE `gallaries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2022_10_11_104413_create_pages_table',1),(6,'2022_10_11_105409_create_posts_table',1),(7,'2022_10_11_112219_create_categories_table',1),(8,'2022_10_11_112436_create_gallaries_table',1),(9,'2022_10_18_205601_create_prices_table',1),(10,'2022_10_19_111102_create_admin_download_prices_table',1),(11,'2022_10_28_092309_create_contacts_table',2),(12,'2022_10_31_130826_create_settings_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) NOT NULL DEFAULT '0',
  `post_id` bigint(20) DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pages_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'Услуги','services',NULL,0,NULL,NULL,'2022-05-10 10:03:03','2022-05-10 10:07:15'),(2,'Продажа асфальтобетона','sale_asphalt',NULL,1,NULL,NULL,'2022-05-10 10:03:03','2022-05-10 10:03:03'),(4,'Аренда спецтехники','lease_technics',NULL,1,NULL,NULL,NULL,NULL),(5,'Строительство дорог','building_dorog',NULL,1,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_ci,
  `mini_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_view` tinyint(1) NOT NULL DEFAULT '1',
  `category_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `page_id` bigint(20) DEFAULT NULL,
  `count_views` bigint(20) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_title_unique` (`title`),
  UNIQUE KEY `posts_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prices`
--

DROP TABLE IF EXISTS `prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` bigint(20) NOT NULL,
  `page_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prices`
--

LOCK TABLES `prices` WRITE;
/*!40000 ALTER TABLE `prices` DISABLE KEYS */;
INSERT INTO `prices` VALUES (1,'СМЕСЬ АСФАЛЬТОБЕТОННАЯ ТИП Б марка II','Тонна',4800,2,'2022-10-19 19:02:57','2022-10-19 19:02:57'),(2,'СМЕСЬ АСФАЛЬТОБЕТОННАЯ ТИП Б марка III','Тонна',4500,2,'2022-10-19 19:03:19','2022-10-19 19:03:19'),(3,'СМЕСЬ АСФАЛЬТОБЕТОННАЯ ТИП В марка II','Тонна',4600,2,'2022-10-19 19:03:44','2022-10-19 19:03:44'),(4,'СМЕСЬ АСФАЛЬТОБЕТОННАЯ ТИП В марка III','Тонна',4300,2,'2022-10-19 19:03:59','2022-10-19 19:03:59'),(5,'СМЕСЬ АСФАЛЬТОБЕТОННАЯ ТИП Г марка II','Тонна',6100,2,'2022-10-19 19:04:27','2022-10-19 19:04:27'),(6,'СМЕСЬ АСФАЛЬТОБЕТОННАЯ ТИП Г марка III','Тонна',4700,2,'2022-10-19 19:04:43','2022-10-19 19:04:43'),(7,'СМЕСЬ АСФАЛЬТОБЕТОННАЯ ТИП Д марка III','Тонна',4500,2,'2022-10-19 19:05:04','2022-10-19 19:05:04'),(8,'СМЕСЬ АСФАЛЬТОБЕТОННАЯ ТИП М марка I','Тонна',4500,2,'2022-10-19 19:05:21','2022-10-19 19:05:21'),(9,'СМЕСЬ АСФАЛЬТОБЕТОННАЯ ТИП М марка II','Тонна',4100,2,'2022-10-19 19:05:38','2022-10-19 19:05:38'),(10,'Экскаватор гусеничный Хитачи','Час',2520,4,'2022-10-19 19:10:36','2022-10-19 19:10:36'),(11,'Экскаватор погрузчик','Час',2700,4,'2022-10-19 19:12:11','2022-10-19 19:12:11'),(12,'Экскаватор погрузчик с бурильной установкой','Час',3200,4,'2022-10-19 19:12:39','2022-10-19 19:12:39'),(13,'Экскаватор погрузчик с гидромолотом','Час',3700,4,'2022-10-19 19:13:03','2022-10-19 19:13:03'),(14,'Экскаватор гусеничный 18т Komatsu','Час',3300,4,'2022-10-19 19:13:27','2022-10-19 19:13:27'),(15,'Экскаватор гусеничный 29т Caterpillar','Час',3600,4,'2022-10-19 19:13:53','2022-10-19 19:13:53'),(16,'Фронтальный погрузчик','Час',2400,4,'2022-10-19 19:14:12','2022-10-19 19:14:12'),(17,'Бульдозер Т170','Час',2280,4,'2022-10-19 19:14:34','2022-10-19 19:14:34'),(18,'Грейдер ГС1402','Час',3500,4,'2022-10-19 19:14:51','2022-10-19 19:14:51'),(19,'Каток двухвальцовый 15т','Час',2700,4,'2022-10-19 19:15:10','2022-10-19 19:15:10'),(20,'Каток комбинированный 10т','Час',2400,4,'2022-10-19 19:15:34','2022-10-19 19:15:34'),(21,'Каток грунтовый Бомаг 18т','Час',2600,4,'2022-10-19 19:15:56','2022-10-19 19:15:56'),(22,'Асфальтоукладчик','Час',6000,4,'2022-10-19 19:16:15','2022-10-19 19:16:15'),(23,'Автокран 25т','Час',2400,4,'2022-10-19 19:16:33','2022-10-19 19:16:33'),(24,'Манипулятор 2,5т дл. 5,5м','Час',5000,4,'2022-10-19 19:16:54','2022-10-19 19:16:54'),(25,'Манипулятор стрела 11м г/п стр. 3т г/п куз 7т','Час',1800,4,'2022-10-19 19:17:18','2022-10-19 19:17:18'),(26,'Длинномер 20т дл. 16.6','Час',1800,4,'2022-10-19 19:17:37','2022-10-19 19:17:37'),(27,'Автотрал 30т дл. 11м','Час',3000,4,'2022-10-19 19:17:54','2022-10-19 19:17:54'),(28,'Камаз 15т/10м3','Час',1400,4,'2022-10-19 19:18:15','2022-10-19 19:18:15'),(29,'Самосвал 10т дл. 7.5 м3','Час',1500,4,'2022-10-19 19:18:31','2022-10-19 19:18:31'),(30,'Самосвал 30т 20м3','Час',2100,3,'2022-10-19 19:18:48','2022-10-19 19:18:48'),(31,'Автомобиль с прицепом до 24т','Час',1700,4,'2022-10-19 19:19:12','2022-10-19 19:19:12'),(32,'Подъемник Genie Z 60/34 высота 22м','Час',5000,4,'2022-10-19 19:19:31','2022-10-19 19:19:31');
/*!40000 ALTER TABLE `prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `site_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` text COLLATE utf8mb4_unicode_ci,
  `email` text COLLATE utf8mb4_unicode_ci,
  `address` text COLLATE utf8mb4_unicode_ci,
  `descriptions` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'Крост - асфальтобетонный завод','+7 (919) 020 79-59','crost2020@yandex.ru','г. Владимир ул. Мостостроевская д.1','Строительство дорог во Владимире.Компания «Крост» работает на строительном рынке и производит готовые смеси.Аренда спецтехники.','Крост','2022-10-31 10:37:13','2022-10-31 10:38:54');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Слободчиков Михаил','slobodchikov1985@yandex.ru',NULL,'$2y$10$pG89Z04QXR5WGvQTKyhY7eoxFIUqfRnXnwiWPguA1RMoHuDHqmtYe',NULL,'2022-10-19 18:59:57','2022-10-19 18:59:57'),(2,'Алек-Медиа','info@alex-media.ru',NULL,'$2y$10$.gpmnKn83LFbAjuIQyLzzusSjkEx.CCW67Tz9eSF3vkHKw.Hg3IYW',NULL,'2022-10-20 05:18:02','2022-10-20 05:18:02'),(3,'Крост','CROST2020@YANDEX.RU',NULL,'$2y$10$1COU6pm4Cosnc0SgdyiInu/RN8BgQStunTC.FbMoBU6oDqj59yjai',NULL,'2022-10-20 05:20:18','2022-10-20 05:20:18');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'alexmedia_crost'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-11 18:40:19
